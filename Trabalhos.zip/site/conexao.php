<?php
$server = "localhost";
$usuario = "root";
$senha = "";
$banconome = "acessibilidade";

$conec = mysqli_connect($server, $usuario, $senha, $banconome);