<?php
error_reporting(0);
session_start();
include_once("conexao.php");

    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $idade = $_POST['idade'];
    $necessidade = $_POST['necessidade'];


$registrar = "INSERT INTO usuarios (nome, sobrenome, email, idade, necessidade) VALUES ('$nome', '$sobrenome', '$email', '$idade', '$necessidade')";
$realizaRegistro = mysqli_query($conec, $registrar);
