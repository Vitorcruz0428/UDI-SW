<?php
include('registroCodigo.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site de acessibilidade</title>
    <link rel="stylesheet" href="styleRegistro.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-light bg-info">
  <strong><a class="navbar-brand" href="#">
    <img src="imagens/icon.png" width="30" height="30" class="d-inline-block align-top" alt="">
    Site de acessibilidade
  </a></strong>
</nav>
<div id="quadrado"><br>
  <form action="" method="POST">
  <h2>Nome:</h2><input type="text" size="20" name="nome">
  <br><br>
  <h2>Sobrenome:</h2><input type="text" size="20" name="sobrenome">
  <br><br>
  <h2>E-mail:</h2><input type="email" size="30" name="email">
  <br><br>
  <h2>Idade:</h2><input type="text" size="10" name="idade">
  <br><br>
  <h2>Necessidade:</h2>
  <br>
  <select name="necessidade">
    <option>Visual</option>
    <option>Auditiva</option>
    <option>Motora</option>
    <option>Outras</option>
    <option>Nenhuma</option>
  </select>
  <br><br><br>
   <button type="submit" name="enviar" class="btn btn-danger btn-lg">Registrar</button>
  </form>
</div>


<footer class="footer mt-auto py-3 fixed-bottom bg-info">
      
      <span class="font-weight-bold" style="margin: 0 25px;">   ♦️  Feito por Vitor Cruz.</span>
            <a href="https://github.com/Vitorcruz0428" target="_blank"><img src="imagens/githubicon.png" width="25" height="25" class="d-inline-block align-right" style="display: flex; float: right; margin: 0 30px;"></a>
        </footer>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>